function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5UhDuiXc2bl":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

